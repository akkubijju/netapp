//================================================================//
//                                                                //
//$Id:$                                                           //
//                                                                //
// stdafx.cpp                                                     //
// stdafx.cpp : source file that includes just the std includes   //
// sm.pch will be the pre-compiled header                         //
// stdafx.obj will contain the pre-compiled type information      //
//                                                                //
// Copyright 2005 Network Appliance, Inc. All rights              //
// reserved. Specifications subject to change without notice.     //
//                                                                //
// This SDK sample code is provided AS IS, with no support or     //
// warranties of any kind, including but not limited to           //
// warranties of merchantability or fitness of any kind,          //
// expressed or implied.  This code is subject to the license     //
// agreement that accompanies the SDK.                            //
//                                                                //
//================================================================//

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
