//================================================================//
//                                                                //
//$Id:$                                                           //
//                                                                //
// stdafx.h :                                                     //
// Include file for standard system include files,or project      //
// specific include files that are used frequently, but are       //
// changed infrequently.                                          //
//                                                                //
// Copyright 2005 Network Appliance, Inc. All rights              //
// reserved. Specifications subject to change without notice.     //
//                                                                //
// This SDK sample code is provided AS IS, with no support or     //
// warranties of any kind, including but not limited to           //
// warranties of merchantability or fitness of any kind,          //
// expressed or implied.  This code is subject to the license     //
// agreement that accompanies the SDK.                            //
//                                                                //
//================================================================//

#pragma once


#include <iostream>
#include <tchar.h>

// TODO: reference additional headers your program requires here
