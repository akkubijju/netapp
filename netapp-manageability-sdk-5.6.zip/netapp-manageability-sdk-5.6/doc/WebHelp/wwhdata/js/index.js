function  WWHBookData_AddIndexEntries(P)
{
var A=P.fA("C",null,null,"002");
var B=A.fA("comments");
var C=B.fA("how to send feedback about documentation",new Array("74"));
A=P.fA("D",null,null,"002");
B=A.fA("documentation");
C=B.fA("how to receive automatic notification of changes to",new Array("74"));
C=B.fA("how to send feedback about",new Array("74"));
A=P.fA("F",null,null,"002");
B=A.fA("feedback");
C=B.fA("how to send comments about documentation",new Array("74"));
A=P.fA("I",null,null,"002");
B=A.fA("information");
C=B.fA("how to send feedback about improving documentation",new Array("74"));
A=P.fA("S",null,null,"002");
B=A.fA("suggestions");
C=B.fA("how to send feedback about documentation",new Array("74"));
A=P.fA("T",null,null,"002");
B=A.fA("Twitter");
C=B.fA("how to receive automatic notification of documentation changes",new Array("74"));
}

function  WWHBookData_MaxIndexLevel()
{
  return 3;
}
